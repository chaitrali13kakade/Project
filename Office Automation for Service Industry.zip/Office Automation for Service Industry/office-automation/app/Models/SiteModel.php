<?php namespace App\Models;

use CodeIgniter\Model;

class SiteModel extends Model{
  public function __construct()
  {
    parent::__construct();
}
protected $table = 'tbl_site';
protected $primaryKey = 'site_id';
protected $allowedFields = ['id ','site_sid','site_name','status'];
    //protected $returnType = '';


public function getRow($site_id){

    //select * from site where id=$id;
    return $this->where('site_id',$site_id)->first();


}
public function add($formData){
    $result=$this->insert($formData);
    return $this->insertID();
    return $this->getLastQuery();
    //return $result;
}

public function savedata($id,$site_id,$site_name,$status)
{
  $data =[
    'id ' => $id,
    'site_sid' => $site_id,
    'site_name' => $site_name,
    'status' => $status,
      ];
      $query = $this->insert($data);
      return $query;
}
public function getCompanyofSite($id){
    
    $result=$this->orderBy('site_name','ASC')->findAll();
    $query = $this->where('id',$id)->findAll();
    //$query= $this->query("select * from tbl_site where id = id");
    //echo $this->getLastQuery();
    return $query;

  }
  public function getSite(){
    $result=$this->orderBy('site_name','ASC')->findAll();
    return $result;
  }


  
}