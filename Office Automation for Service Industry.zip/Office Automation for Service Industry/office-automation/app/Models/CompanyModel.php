<?php namespace App\Models;

use CodeIgniter\Model;

class CompanyModel extends Model{
  public function __construct()
  {
    parent::__construct();
  }
  protected $table = 'tbl_company';
  protected $primaryKey = 'id';
  protected $allowedFields = ['company_id','company_name','status'];
  
  public function getRow($id){

    //select * from company where id=$id;

    return $this->where('id',$id)->first();
  }

  public function getCompany(){
    $result=$this->orderBy('company_name','ASC')->findAll();
    return $result;
  }



  public function addCompanydata($formdata)
  {
    $query=$this->insert($formdata);
    
  }
  
  

}


