<?php namespace App\Models;

use CodeIgniter\Model;

class AttendanceModel extends Model{
  public function __construct()
  {
    parent::__construct();
  }
  protected $table = 'tbl_attendancemaster';
  protected $primaryKey = 'attendance_id';
  protected $allowedFields = ['year','month','working_days','service','no_of_nationalholidays'];

  public function get_year()
  {
    $result=$this->orderBy('year','ASC')->findAll();
    return $result;
  }
  public function get_month()
  {
    $result=$this->orderBy('month','ASC')->findAll();
    return $result;
  }
}
