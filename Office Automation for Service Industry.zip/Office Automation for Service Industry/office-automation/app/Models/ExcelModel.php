<?php namespace App\Models;

use CodeIgniter\Model;

class ExcelModel extends Model{
  public function __construct()
  {
    parent::__construct();
  }
  protected $table = 'tbl_product';
  protected $primaryKey = 'id';
  protected $allowedFields = ['product_name','product_quantity','product_price'];

  public function insert_batch($data){
		$this->insertBatch($data);
		if($this->affectedRows()>0)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	public function product_list()
	{
		
		$query=$this->findAll();
		return $query;
	}
}
