<?php namespace App\Models;

use CodeIgniter\Model;

class EmployeeTransactionModel extends Model{
  public function __construct()
  {
    parent::__construct();
  }
  protected $table = 'tbl_emptransaction';
  protected $primaryKey = '	id';
  protected $allowedFields = ['year','month','employee_id','employee_name','branch','working_days','overtime'];

  public function insert_batch($data){
		$this->insertBatch($data);
		if($this->affectedRows()>0)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
}
