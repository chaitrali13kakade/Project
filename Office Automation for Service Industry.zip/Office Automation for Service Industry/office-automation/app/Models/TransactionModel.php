<?php namespace App\Models;

use CodeIgniter\Model;

class TransactionModel extends Model{
  public function __construct()
  {
    parent::__construct();
  }
  protected $table = 'tbl_transactionmaster';
  protected $primaryKey = 'trans_id';
  protected $allowedFields = ['year','month','site_name','employee_id','employee_name','employee_designnation','employee_present_days','employee_weeklyoff','employee_extraduties','total'];

  public function getid($employee_id)
  {
    
    $this->select('*');
		$this->where('employee_id',$employee_id);
		$num_results = $this->findAll();
    return $num_results;
  }

  

  //import excel
  public function insert_data($data)
{   
		$this->insertBatch($data);
		if($this->affectedRows()>0)
		{
			return 1;
		}
		else{
			return 0;
		}
   

}
public function getExcelData(){
  $result=$this->findAll();
  return $result;
}

  
	
}