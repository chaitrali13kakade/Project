<?php namespace App\Models;

use CodeIgniter\Model;

class MappingForm_model extends Model{
	public function __construct()
	{
		parent::__construct();
	}
	protected $table = 'tbl_mapform';
	protected $primaryKey = 'map_id';
	protected $allowedFields = ['site_id','payroll_name','billing_name'];

	public function getRow($map_id)
	{
		return $this->where('map_id',$map_id)->first();
	}  

	public function savedata($site_id,$payroll_name,$billing_name)
	{
	$data =[
		'site_id' => $site_id,
		'payroll_name' => $payroll_name,
		'billing_name' => $billing_name,
		
		];
		$query = $this->insert($data);
		return $query;
	}
}