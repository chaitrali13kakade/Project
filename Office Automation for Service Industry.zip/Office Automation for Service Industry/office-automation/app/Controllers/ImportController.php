<?php
namespace App\Controllers;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\CompanyModel;
use App\Models\TransactionModel;
use App\Models\SiteModel;
use App\Models\AttendanceModel;
  
class ImportController extends BaseController
{
   function __contruct()
   {
    parent::__construct();/* call CodeIgniter's default Constructor */
    $this->load->model('SiteModel');/* load Model SiteModel */
    $this->load->model('CompanyModel');/* load Model CompanyModel*/
    $this->load->model('TransactionModel');/* load Model TransactionModel */
    $this->load->model('AttendanceModel');/* load Model AttendanceModel*/
   }
   public function ImportExcel()
   
   {
    $data = [];
    helper(['form']);//load the helper
    $session=session();//load the session

    //get site_name using SiteModel
    $model = new SiteModel();
    $result=$model->getSite();
    $data['site']=$result;
    
    //get year and month using AttendanceModel
    $atttendance_model=new AttendanceModel();
    $result_year =$atttendance_model->get_year();
    $data['year']=$result_year;
 
    $result_month =$atttendance_model->get_month();
    $data['month']=$result_month;



    if($this->request->getMethod() == 'post'){
     //validation
     $rules = [
      'sheetname' => 'required',
      'year' => 'required',
      'month'=> 'required',
      'site_name' => 'required',
      'employee_total' => 'required',
      'present_days' => 'required',
      'weekly_off' => 'required',
      'over_time' => 'required',
     ];
     if(! $this->validate($rules)){
      $data['validation'] = $this->validator;
     }else{

    //insert excel data using TransactionModel
    $tmodel = new TransactionModel();
   
    $sheetname=$this->request->getPost('sheetname');
    $year=$this->request->getPost('year');
    $month=$this->request->getPost('month');
    $site_name = $this->request->getPost('site_name');
    $employee_total=$this->request->getPost('employee_total');
    $present_days=$this->request->getPost('present_days');
    $weekly_off=$this->request->getPost('weekly_off');
    $over_time=$this->request->getPost('over_time');
    // echo $employee_total;
    // echo $present_days;
    // echo $weekly_off;
    // echo $over_time;
    
    // Validation
    $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		  // Check form submit or not 
    if(isset($_FILES['upload_file']['name']) && in_array($_FILES['upload_file']['type'], $file_mimes))
    {
     //select file posted for inserting data
     $arr_file = explode('.', $_FILES['upload_file']['name']);
     //check file extension
     $extension = end($arr_file);
     if('csv' == $extension)
     {	// instantiate Csv
      $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
     } 
     else
     {	// instantiate Xlsx
      $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
     }
     //load only certain sheets from the file
     $reader->setLoadSheetsOnly($sheetname);
     $reader->setReadDataOnly( true );
     $spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
     $allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null,true,true,true); // here i get all data from excel sheet
     $highestrow = $spreadsheet->getActiveSheet()->getHighestRow();
     $highestcolumn = $spreadsheet->getActiveSheet()->getHighestColumn();
     //print_r($sheetData);
     $arrayCount=count($allDataInSheet);
     if($arrayCount>1)
     {

     $insertArray = array(); // we can use this array to run insert query.
     for($i=6,$col=5;$i<$highestrow;$i++){  //$i should be 4 in your sheet.
      $emp_idcode_key = array_search ('ID Code', $allDataInSheet[$col]); // I'll find required column in first row to get his index or column name from excel
      $emp_name_key = array_search ('Name of the Employee', $allDataInSheet[$col]);
      $emp_design_key = array_search ('Design', $allDataInSheet[$col]);
      $emp_present_days_key = array_search ('Present Days', $allDataInSheet[$col]);
      $emp_wo_key = array_search ('WO', $allDataInSheet[$col]);
      $emp_ot_key = array_search ('Extra Duty', $allDataInSheet[$col]);
      $emp_total_key = array_search ('Total', $allDataInSheet[$col]);
      
      if ($i>$col) {
        $employee_id = trim($allDataInSheet[$i][$emp_idcode_key]);
        $employee_name = trim($allDataInSheet[$i][$emp_name_key]);
        $employee_designnation = trim($allDataInSheet[$i][$emp_design_key]);
        $employee_present_days = trim($allDataInSheet[$i][$emp_present_days_key]);
        $employee_weeklyoff = trim($allDataInSheet[$i][$emp_wo_key]);
        $employee_extraduties = trim($allDataInSheet[$i][$emp_ot_key]);
        $total = trim($allDataInSheet[$i][$emp_total_key]);
        if (strpos($employee_id, 'GW') === 0)
        {   
        echo "<pre>";
        //get employee_id using TransactionModel for checking employee_id is already exists or not
        $resultdata=$tmodel->query("select employee_id from tbl_transactionmaster where employee_id='$employee_id'");
        $arraydata=$resultdata->getNumRows();

        $insertArray[]=array(
                    'year'=>$year,
                    'month'=>$month,
                    'site_name'=> $site_name,
                    'employee_id'=> $employee_id,
                    'employee_name' =>$employee_name,
                    'employee_designnation'=>$employee_designnation,
                    'employee_present_days'=>$employee_present_days,
                    'employee_weeklyoff' => $employee_weeklyoff,
                    'employee_extraduties'=>$employee_extraduties,
                    'total' => $total,
                  );
       
        }
      }
      }
     }
      //print_r($insertArray);
      //array_column() function returns a single values from single column in the array
    $array_total = array_column($insertArray, 'total');
    $array_present_days=array_column($insertArray, 'employee_present_days');
    $array_weekly_off=array_column($insertArray, 'employee_weeklyoff');
    $array_over_time=array_column($insertArray, 'employee_extraduties');
      // echo "<pre>";
      // print_r($array_total); 
      // print_r($array_present_days); 
      // print_r($array_weekly_off); 
      // print_r($array_over_time); 

    //array_sum() function returns the sum of all values in array
    $sum_prrsent_days=array_sum($array_present_days);  
    $sum_weekly_off=array_sum($array_weekly_off); 
    $sum_over_time=array_sum($array_over_time); 
    $sum_total=array_sum($array_total); 
    // print_r($sum_prrsent_days); 
    // print_r($sum_weekly_off); 
    // print_r($sum_over_time); 
    // print_r($sum_total); 
    

    if($arraydata === 0)
    {
      //echo "not exists";
      if($sum_total == $employee_total && $sum_prrsent_days == $present_days && $sum_weekly_off == $weekly_off && $sum_over_time == $over_time)
      {
        //Calling modal function to insert into table
        $inserdata=$tmodel->insert_data($insertArray);
        $session->setFlashdata('success','Excel File Imported Successfuly!');
        return redirect()->to('/ImportReport/importexcel'); 
      }
      else
      {
        //echo "There is difference in total. Please kindly Check...";
        $session->setFlashdata('error','There is difference in total. Please kindly Check...');
      return redirect()->to('/ImportReport/importexcel'); 
      }
         
    }
    else
    {
      //echo "already exists.";
      $session->setFlashdata('error','Data Already Exist.');
      return redirect()->to('/ImportReport/importexcel'); 
    }
   }   
  }
 } 
    //load the view/templates/header.php with $data
    echo view('templates/header', $data);
    //load the view/ImportReport/importexcel.php 
    echo view('ImportReport/importexcel');
    //load the view/templates/footer.php 
    echo view('templates/footer');
   }
}