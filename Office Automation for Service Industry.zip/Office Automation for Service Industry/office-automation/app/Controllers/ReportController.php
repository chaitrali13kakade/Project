<?php

namespace App\Controllers;
use App\Models\CompanyModel;
use App\Models\SiteModel;
use App\Models\MappingForm_model;
use App\Libraries\CompanyPdf; // Import  CompanyPdf library 
use App\Libraries\SitePdf; // Import SitePdf library 
use App\Libraries\MapFormPdf; // Import MapFormPdf library 
use App\Libraries\CompanyExcel; // Import CompanyExcellibrary 
use App\Libraries\SiteExcel; // Import SiteExcel library 
use App\Libraries\MapformExcel; // Import MapformExcel library 
use App\Libraries\AllExcelFile; // Import AllExcelFile library 

class ReportController extends BaseController
{
	function __contruct()
	{
		parent::__construct(); /* call CodeIgniter's default Constructor */
		$this->load->model('UserModel'); /* load Model UserModel */
		$this->load->model('CompanyModel'); /* load Model CompanyModel */
		$this->load->model('SiteModel'); /* load Model SiteModel */
		$this->load->model('MappingForm_model'); /* load Model MappingForm_model */
	}

	public function index()
	{
		$data = [];
		helper(['form']);
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/report.php
		echo view('GenerateReport/report');
		//load the view/templates/footer.php 
		echo view('templates/footer');
		
	}
	public function getCompanyDetails(){
		$data = [];
		helper(['form']);
		$model = new CompanyModel();
		$result=$model->findAll();
		$data['company']=$result;
		echo view('GenerateReport/companyFile', $data);
	}
	
	public function ReportGeneration(){
		$data = [];
		helper(['form']);
		//get post data
		$selectFile =  $this->request->getPost('selectFile') ;
		$radioButton = $this->request->getPost('radioButton');
		$formSubmit = $this->request->getPost('download');


		if($selectFile == 'company')
		{
			if($radioButton == 'pdf')
			{

				$companypdf = new CompanyPdf(); // create an instance of Library
				return $companypdf->createCompanypdf(); // calling method
			}
			elseif ($radioButton == 'excel') {
				$CompanyExcel = new CompanyExcel();// create an instance of Library
				return $CompanyExcel->createCompanyExcel(); // calling method
			}
		}
		elseif($selectFile == 'site')
		{
			if($radioButton == 'pdf')
			{
				$sitepdf = new SitePdf(); // create an instance of Library
				return $sitepdf->createSitepdf(); // calling method
				
			}
			elseif ($radioButton == 'excel') {
				$SiteExcel = new SiteExcel(); // create an instance of Library
				return $SiteExcel->createSiteExcel(); // calling method
				
			}
		}
		
		elseif($selectFile == 'mapform')
		{
			if($radioButton == 'pdf')
			{
				$mapformpdf = new MapFormPdf(); // create an instance of Library
				return $mapformpdf->createMapformpdf(); // calling method
			}
			elseif ($radioButton == 'excel') 
			{
				$MapformExcel = new MapformExcel(); // create an instance of Library
				return $MapformExcel->createMapformExcel(); // calling method
				
			}
		}
		elseif($selectFile == 'allfiles')
		{
			if($radioButton == 'pdf')
			{
				// $allfilepdf = new MapFormPdf();
				// return $allfilepdf->createAllpdf();
			}
			elseif ($radioButton == 'excel') 
			{
				$allfileExcel = new AllExcelFile(); // create an instance of Library
				return $allfileExcel->demoexcel(); // calling method
				
			}
		}
		
		else
		{
			echo "Not Found";
			return redirect()->to('/GenerateReport/report');
		}
		
	}

}
