<?php

namespace App\Controllers;
use App\Models\AttendanceModel;

class AttendanceController extends BaseController
{
	function __contruct()
	{
		parent::__construct();/* call CodeIgniter's default Constructor */
		$this->load->model('AttendanceModel');/* load Model AttendanceModel*/
	}
	//create attendance form using this method
	public function createAttendance()
	{
		$data = [];
		helper(['form', 'url']);
		$model=new AttendanceModel();
		if($this->request->getMethod() == 'post')
		{
			//validation
			$rules = [
				'year' => 'required',
				'month' => 'required',
				'working_days' => 'required',
				'service' => 'required',
				'no_of_nationalholidays' => 'required'
			];
			

			if(! $this->validate($rules))
			{
				$data['validation'] = $this->validator;
			}
			else
			{
				//save post data into an $newData array
				$newData = [
					'year' => $this->request->getVar('year'),
					'month' => $this->request->getVar('month'),
					'working_days' => $this->request->getVar('working_days'),
					'service' => $this->request->getVar('service'),
					'no_of_nationalholidays' => $this->request->getVar('no_of_nationalholidays'),
				];
				//insert attendance record
				$model->insert($newData);
				$session = session();
				$session->setFlashdata('success','Successfuly Save');				
				return redirect()->to('AttendanceForm');
				
			}
		}
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/tAttendanceForm.php with $data
		echo view('AttendanceForm',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}
}
