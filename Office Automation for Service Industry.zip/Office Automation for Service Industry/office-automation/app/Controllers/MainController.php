<?php

namespace App\Controllers;

use App\Models\UserModel;


class MainController extends BaseController
{
	function __contruct()
	{
		parent::__construct();/* call CodeIgniter's default Constructor */
		$this->load->model('UserModel');/* load Model UserModel */
		

	}
	//index method for login
	public function index()
	{
		$data = [];
		helper(['form']);
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [	
				'username'=> 'required|min_length[4]|max_length[20]',
				'password' => 'required|min_length[4]|max_length[20]|validateUser[username,password]',

			];
			$errors = [
				'password' => [
					'validateUser' => 'Username or  Password don\'t match'
				]
			];
			if(! $this->validate($rules,$errors)){
				$data['validation'] = $this->validator;
			}
			else{
				$model = new UserModel();
				$user = $model->where('username',$this->request->getVar('username'))->first();				
				$this->setUserSession($user);
				//return redirect()->to('dashboard');
				return redirect()->to('searchCompany');
			}
		}
		//echo view('templates/header', $data);
		echo view('OfficeLogin');
		//echo view('login');
		//echo view('templates/footer');
	}

	private function setUserSession($user){
		$data = [
			'user_id' => $user['user_id'],
			'firstname' => $user['firstname'],
			'lastname' => $user['lastname'],
			'username' => $user['username'],
			'password' => $user['password'],
			'isLoggedIn' => true,
		];
		session()->set($data);
		return true;
	}
	//new registration
	public function register(){
		$data = [];
		helper(['form']);
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'firstname' => 'required|min_length[4]|max_length[20]',
				'lastname' => 'required|min_length[4]|max_length[20]',
				'username'=> 'required|min_length[4]|max_length[20]',
				'password' => 'required|min_length[4]|max_length[20]',
			];
			if(! $this->validate($rules)){
				$data['validation'] = $this->validator;
			}else{
				$model = new UserModel();

				//get from values into the array
				$newData = [
					'firstname' => $this->request->getVar('firstname'),
					'lastname' => $this->request->getVar('lastname'),
					'username' => $this->request->getVar('username'),
					'password' => $this->request->getVar('password'),
				];
				//save array into the database using UserModel
				$model->save($newData);
				$session = session();
				$session->setFlashdata('success','Successful Registration');
				return redirect()->to('/');
			}
		}
		//load the view/templates/header.php with $data
		//echo view('templates/header', $data);
		//load the view/register.php with $data
		echo view('register');
		//load the view/templates/footer.php 
		echo view('templates/footer');
	}

	//display user information/profile
	public function  profile(){
		$data = [];
		helper(['form']);
		$model = new UserModel();
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'firstname' => 'required|min_length[3]|max_length[20]',
				'lastname' => 'required|min_length[3]|max_length[20]',
			];
			if($this->request->getPost('password') != ''){
				$rules['password'] = 'required|min_length[8]|max_length[255]';
			}
			if(! $this->validate($rules)){
				$data['validation'] = $this->validator;
			}else{
				$newData = [
					'user_id' => session()->get('user_id'),
					'firstname' => $this->request->getPost('firstname'),
					'lastname' => $this->request->getPost('lastname'),
				];
				if($this->request->getPost('password') != ''){
					$newData['password'] = $this->request->getPost('password');					
				}
				$model->save($newData);			
				session()->setFlashdata('success','Successfuly Updated');
				return redirect()->to('/profile');
			}
		}
		$data['user'] = $model->where('user_id', session()->get('user_id'))->first();
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/profile.php 
		echo view('profile');
		//load the view/templates/footer.php
		echo view('templates/footer');
	}
	//method fro logout from the system
	public function logout(){
		session()->destroy();
		return redirect()->to('/');

	}
}