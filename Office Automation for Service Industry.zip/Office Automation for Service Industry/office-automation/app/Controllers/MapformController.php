<?php

namespace App\Controllers;
use App\Models\SiteModel;
use App\Models\MappingForm_model;

class MapformController extends BaseController
{
	function __contruct()
	{
		parent::__construct(); /* call CodeIgniter's default Constructor */
		$this->load->model('SiteModel'); /* load Model SiteModel*/
		$this->load->model('MappingForm_model'); /* load Model MappingForm_model*/
	}
	//mapping form
	public function mapForm(){
		$data = [];
		helper(['form']);
		$sessio=session();

		//get site details using SiteModel
		$model = new SiteModel();
		$result=$model->getSite();
		$data['site']=$result;
		
		$smodel = new MappingForm_model();
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'payroll_name' => 'required|min_length[6]|max_length[100]',
				'billing_name' => 'required|min_length[3]|max_length[100]',
				
			];
			if(! $this->validate($rules))
			{
				$data['validation'] = $this->validator;
			}
			else
			{
				//get post data
				$site_id = $this->request->getPost('site_id');
				$payroll_name = $this->request->getPost('payroll_name');
				$billing_name = $this->request->getPost('billing_name');

				//insert data into database
				//$isInserted=$smodel->query("INSERT INTO `tbl_mapform` ( `site_id`, `payroll_name`, `billing_name`) VALUES ( '$site_id', '$payroll_name', '$billing_name')");
				$isInserted = $smodel->savedata($site_id,$payroll_name,$billing_name);
				$session = session();
				if(!empty($isInserted))
				{
					//display success message
					$session->setFlashdata('success','Successfuly Save');
					echo $smodel->getLastQuery() ;				
					return redirect()->to('/searchMappingform');	
				}
				else
				{
					//display error message
					$session->setFlashdata('error','Data Not Inserted');				
					return redirect()->to('/mapForm');

				}			
			}
		}
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/mapForm.php with $data
		echo view('mapForm',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
		
	}
	//list mapping form details
	public function searchMappingform(){
		$data = [];
		helper(['form']);
		//get mapping from details using MappingForm_model
		$model = new MappingForm_model();		
		//$data['site']=$model->query('select * from tbl_site');
		$data['mapform']=$model->findAll();
		
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/searchMappingform.php with $data
		echo view('searchMappingform',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}

	public function UpdateMappingForm($map_id)
	{
		$data = [];
		helper(['form']);
		$sessio=session();

		//get site details using SiteModel
		$model = new SiteModel();
		$result=$model->getSite();
		$data['site']=$result;
		
		$smodel = new MappingForm_model();	
		$mapform=$smodel->getRow($map_id);
		if(empty($mapform))
		{
			$session = session();
			$session->setFlashdata('error',"Data not found.");
			return redirect()->to('/searchMappingform');
		}
		$data['mapform']=$mapform;

		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'payroll_name' => 'required|min_length[6]|max_length[100]',
				'billing_name' => 'required|min_length[3]|max_length[100]',
				
			];
			if(! $this->validate($rules))
			{
				$data['validation'] = $this->validator;
			}
			else
			{
				//get post data
				$newData=[
					'site_id' => $this->request->getPost('site_id'),
					'payroll_name' => $this->request->getPost('payroll_name'),
					'billing_name' => $this->request->getPost('billing_name'),

				];
				
				//insert data into database
				//$isInserted=$smodel->query("INSERT INTO `tbl_mapform` ( `site_id`, `payroll_name`, `billing_name`) VALUES ( '$site_id', '$payroll_name', '$billing_name')");
				$isUpdated=$smodel->update($map_id,$newData);
				$session = session();
				if(!empty($isUpdated))
				{
					//display success message
					$session->setFlashdata('success','Updated Successfully');
					echo $smodel->getLastQuery() ;				
					return redirect()->to('/searchMappingform');	
				}
				else
				{
					//display error message
					$session->setFlashdata('error','Not Updated.');				
					return redirect()->to('/UpdateMappingForm');

				}			
			}
		}
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/mapForm.php with $data
		echo view('UpdateMappingForm',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');

	}

	//this function deletes mapping form record
	public function deleteMapForm($map_id){
		$data = [];
		helper(['form']);
		//get map_id using getRow()
		$model = new MappingForm_model();
		$map_id=$model->getRow($map_id);
		$session = session();
		if(empty($map_id)){
			$session->setFlashdata('error','Record not found.');
			return redirect()->to('/searchMappingform');
		}
		else{
			//delete record
		$model->delete($map_id);
		$session->setFlashdata('success','Successfully deleted.');
		return redirect()->to('/searchMappingform');

		}
		

	}
}