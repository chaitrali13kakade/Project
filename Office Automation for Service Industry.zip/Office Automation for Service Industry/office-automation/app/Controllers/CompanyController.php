<?php
namespace App\Controllers;
use App\Models\CompanyModel;

class CompanyController extends BaseController
{
	function __contruct()
	{
		parent::__construct();/* call CodeIgniter's default Constructor */
		$this->load->model('CompanyModel');/* load Model CompanyModel*/
	}
	
	//create new company
	public function company(){
		$data = [];
		helper(['form']);
		$session = session();
		//get company details using CompanyModel
		$model = new CompanyModel();
		$data['company']=$model->findAll();

		//post data
		$company_id = $this->request->getVar('company_id');
		$company_name = $this->request->getVar('company_name');
		if($this->request->getMethod() == 'post')
		{
			//validation
			$rules = [
				'company_id' => 'required|min_length[3]|max_length[50]',
				'company_name' => 'required|min_length[3]|max_length[50]',
				'status' => 'required',
			];
			if(! $this->validate($rules))
			{
				$data['validation'] = $this->validator;
			}
			else
			{
				//geting company_id using CompanyModel
				$companydata=$model->query("select company_id from tbl_company where company_id='$company_id' ");
				$arraydata=$companydata->getNumRows();
      			//print_r($arraydata) ;
				  //this method checks if data is already exists or not
				  if($arraydata === 0)
				  {
					$newData = [
						'company_id' => $this->request->getVar('company_id'),
						'company_name' => $this->request->getVar('company_name'),
						'status' => $this->request->getVar('status'),
					];
					//$newData is insrted into database
					$model->addCompanydata($newData);
					//return $this->insertID();
					
					$session->setFlashdata('success','Successfuly Save');				
					return redirect()->to('searchCompany');
					return $model->insertID();

				  }
				  else
				  {
					
					$session->setFlashdata('error','Company Id Already Exist');				
					return redirect()->to('searchCompany');

				  }

				
			}
		}
		 //load the view/templates/header.php with $data
		echo view('templates/header', $data);
		 //load the view/company.php with $data
		echo view('company',$data);
		 //load the view/templates/footer.php with $data
		echo view('templates/footer');
	}
	//list company data
	public function searchCompany(){
		$data = [];
		helper(['form']);
		$model = new CompanyModel();		
		//$data['company']=$model->query('select * from tbl_company');
		$data['company']=$model->getCompany();

		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/searchCompany.php with $data
		echo view('searchCompany',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}
	//edit company data
	public function edit($id){
		$session = session();
		//echo $id;
		$data = [];
		helper(['form']);
		//get sigle company id using CompanyModel getRow() method
		$model = new CompanyModel();	
		$company=$model->getRow($id);
		//print_r($company);
		//check company id is exist or not
		if(empty($company))
		{
			$session = session();
			$session->setFlashdata('error',"Data not found.");
			return redirect()->to('/searchCompany');
		}
		//save $company record into data array
		$data['company']=$company;

		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'company_id' => 'required|min_length[3]|max_length[20]',
				'company_name' => 'required|min_length[6]|max_length[50]',
			];
			if(! $this->validate($rules)){
				$data['validation'] = $this->validator;
			}
			else{
				
				$newData = [
					'id' => $this->request->getVar('id'),
					'company_id' => $this->request->getVar('company_id'),
					'company_name'=> $this->request->getVar('company_name'),
					'status'=> $this->request->getVar('status'),
				];
				//Company data is updated using upadte method
				$model->update($id,$newData);
				$session->setFlashdata('success','Record updated successfully......!!!!');
				return redirect()->to('/searchCompany');
			}
		}
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/edit.php with $data
		echo view('edit',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}
	//delete company data
	public function delete($id){
		$data = [];
		helper(['form']);
		$session = session();
		//get single company id using CompanyModel() getRow() method
		$model = new CompanyModel();
		$company=$model->getRow($id);
		
		if(empty($company)){
			$session->setFlashdata('error','Record not found.');
			return redirect()->to('/searchCompany');
		}
		else{
			//delete record using CompanyModel() delete() method
		$model->delete($id);
		$session->setFlashdata('success','Successfully deleted.');
		return redirect()->to('/searchCompany');

		}
		

	}
	

}
?>