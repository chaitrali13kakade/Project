<?php
namespace App\Controllers;

//require FCPATH.'vendor/autoload.php';

use App\Models\ExcelModel;
use App\Models\EmployeeTransactionModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExcelController extends BaseController {

	function __contruct()
	{
		parent::__construct();
		$this->load->model('ExcelModel');
		
	}
	
	public function index()
	{
		$data = [];
		helper(['form']);
		
		echo view('templates/header', $data);
		echo view('importfromexcel');
		echo view('templates/footer');
		
	}
	public function spreadhseet_format_download()
	{
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="hello_world.xlsx"');
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$sheet->setCellValue('A1', 'S.No');
		$sheet->setCellValue('B1', 'Product Name');
		$sheet->setCellValue('C1', 'Quantity');
		$sheet->setCellValue('D1', 'Price');

		$writer = new Xlsx($spreadsheet);
		$writer->save("php://output");
	}
	public function spreadsheet_import()
	{
		helper('filesystem');
		$session=session();
		//$model=new ExcelModel();
		$model=new EmployeeTransactionModel();
		
		$file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		if(isset($_FILES['upload_file']['name']) && in_array($_FILES['upload_file']['type'], $file_mimes)) {
			$arr_file = explode('.', $_FILES['upload_file']['name']);
			$extension = end($arr_file);
			if('csv' == $extension){
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} else {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			}
			$spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
			$sheetData = $spreadsheet->getActiveSheet()->toArray();
			//$sheetData = $spreadsheet->getActiveSheet()->getHighestRow();
			

//$all = $spreadsheet->getSheetNames()[1];
			echo'<pre>';
			print_r($sheetData);
			if (!empty($sheetData)) {
				$sheetcount=count($sheetData);
				if($sheetcount>1)
				{
					$data=array();

					for ($i=1; $i < $sheetcount; $i++)
					{
						$year=$sheetData[$i][1];
						$month=$sheetData[$i][2];
						$employee_id=$sheetData[$i][3];
						$employee_name=$sheetData[$i][4];
						$branch=$sheetData[$i][5];
						$working_days=$sheetData[$i][13];
						$overtime=$sheetData[$i][14];

						$data[]=array(
							'year'=>$year,
							'month'=>$month,
							'employee_id' => $employee_id,
							'employee_name'=>$employee_name,
							'branch' => $branch,
							'working_days'=> $working_days,
							'overtime' => $overtime,

						);
					}
					$inserdata=$model->insert_batch($data);
					if($inserdata)
					{
						$session->setFlashdata('success','Successfuly Save');
						return redirect()->to('/importfromexcel');
					} 
					else 
					{
						$session->setFlashdata('error','Data Not uploaded. Please Try Again.');
						return redirect()->to('/importfromexcel');
					}
				}
			}
		}
	}

	public function importFile()
	{
		helper('filesystem');
		$session=session();
		//$model=new ExcelModel();
		$model=new EmployeeTransactionModel();
		
		$file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

		if(isset($_FILES['upload_file']['name']) && in_array($_FILES['upload_file']['type'], $file_mimes)) 
		{
			$arr_file = explode('.', $_FILES['upload_file']['name']);
			$extension = end($arr_file);
			if('csv' == $extension)
			{
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} 
			else
			{
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			}
			$spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
			$sheetData = $spreadsheet->getActiveSheet();
			//$sheetData = $spreadsheet->getActiveSheet()->getHighestRow();
			echo'<pre>';
			print_r($sheetData);
		}
	}


	public function spreadsheet_export()
	{
		//fetch my data
		$model=new ExcelModel();
		$productlist=$model->product_list();
		print_r($productlist);

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="product.xlsx"');
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$sheet->setCellValue('A1', 'S.No');
		$sheet->setCellValue('B1', 'Product Name');
		$sheet->setCellValue('C1', 'Quantity');
		$sheet->setCellValue('D1', 'Price');
		$sheet->setCellValue('E1', 'Subtotal');

		$sn=2;
		foreach ($productlist as $prod) {
			//echo $prod->product_name;
			$sheet->setCellValue('A'.$sn,$prod->product_id);
			$sheet->setCellValue('B'.$sn,$prod->product_name);
			$sheet->setCellValue('C'.$sn,$prod->product_quantity);
			$sheet->setCellValue('D'.$sn,$prod->product_price);
			$sheet->setCellValue('E'.$sn,'=C'.$sn.'*D'.$sn);
			$sn++;
		}
		//TOTAL
		$sheet->setCellValue('D8','Total');
		$sheet->setCellValue('E8','=SUM(E2:E'.($sn-1).')');

		$writer = new Xlsx($spreadsheet);
		$writer->save("php://output");
	}
}