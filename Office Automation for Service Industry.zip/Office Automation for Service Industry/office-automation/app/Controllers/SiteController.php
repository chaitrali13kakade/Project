<?php

namespace App\Controllers;
use App\Models\CompanyModel;
use App\Models\SiteModel;
class SiteController extends BaseController
{
	function __contruct()
	{
		parent::__construct();/* call CodeIgniter's default Constructor */
		$this->load->model('SiteModel');/* load Model SiteModel*/
		$this->load->model('CompanyModel');/* load Model CompanyModel*/
	}
	
	//Create new site record
	public function site()
	{
		$data = [];
		helper(['form']);
		$session = session();
		$smodel = new SiteModel();		
		//$id =$this->request->getPost('id');
		$model=new CompanyModel();
		$result=$model->getCompany();
		$data['company']=$result;
		
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'site_sid' => 'required|min_length[3]|max_length[50]',
				'site_name' => 'required|min_length[3]|max_length[50]',
				
			];
			if(! $this->validate($rules))
			{
				$data['validation'] = $this->validator;
			}
			else
			{
				$id = $this->request->getPost('id');
				//print_r($id);
				$site_sid = $this->request->getPost('site_sid');
				$site_name = $this->request->getPost('site_name');
				$status = $this->request->getPost('status');

				//getting site_sid using SiteModel for checking if it is already exists or not
				$result=$smodel->query("select site_sid from tbl_site where site_sid='$site_sid'");
				$arraydata=$result->getNumRows();
				//this method checks if data is already exists or not
				if($arraydata === 0)
				{
					// $isInserted=$smodel->query("INSERT INTO `tbl_site` ( `id`, `site_sid`, `site_name`, `status`) VALUES ('$id', '$site_sid', '$site_name', '$status')");
					$isInserted = $smodel->savedata($id,$site_sid,$site_name,$status);
					//this method check data is inserted or not
					if(!empty($isInserted))
					{
						//inserted
						$session->setFlashdata('success','Successfuly Save');				
						return redirect()->to('/searchSite');	
					}
					else
					{
						//not inserted
						$session->setFlashdata('error','Data Not Inserted');				
						return redirect()->to('/site');

					}	
				}
				else{
					//display error if data already exists
					$session->setFlashdata('error','Site Id Already Exist');				
					return redirect()->to('searchSite');

				}

						
			}
		}


		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/site.php with $data
		echo view('site',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');	
	}

	
	//display site record using this function
	public function searchSite()
	{
		$data = [];
		helper(['form']);

		//get site record using SiteModel()
		$model = new SiteModel();
		//$data['site']=$model->query('select * from tbl_site');
		$data['site']=$model->findAll();
		
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/searchSite.php with $data
		echo view('searchSite',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}

	//update site record
	public function editSite($id){
		$session = session();
	//echo $id;
		$data = [];
		helper(['form']);

		//get company details using CompanyModel()
		$model1 = new CompanyModel();
		//$data['company']=$model->query('select distinct company_name from company');
		
		$data['company']=$model1->query('select * from tbl_company');
		$data['company']=$model1->get();

		//get signle site id using SiteModel()
		$model = new SiteModel();
		$site=$model->getRow($id);
		//print_r($company);
		//check selected site id is exist or not
		if(empty($site))
		{
			$session = session();
			$session->setFlashdata('error',"Data not found.");
			return redirect()->to('/searchSite');
		}
		////save $site record into data array
		$data['site']=$site;
		if($this->request->getMethod() == 'post'){
			//validation
			$rules = [
				'site_sid' => 'required|min_length[3]|max_length[20]',
				'site_name' => 'required|min_length[6]|max_length[50]',
			];
			if(! $this->validate($rules)){
				$data['validation'] = $this->validator;
			}else{
				//get post data into an $newData array
				$newData = [
					'id' => $this->request->getVar('id'),
					'site_sid' => $this->request->getVar('site_sid'),
					'site_name'=> $this->request->getVar('site_name'),
					'status'=> $this->request->getVar('status'),
				];
				//data updated 
				$model->update($id,$newData);
				$session->setFlashdata('success','Record updated successfully......!!!!');
				return redirect()->to('/searchSite');
			}
		}
		//load the view/templates/header.php with $data
		echo view('templates/header', $data);
		//load the view/editSite.php with $data
		echo view('editSite',$data);
		//load the view/templates/footer.php with $data
		echo view('templates/footer');
	}

	//this function delete site details
	public function deleteSite($site_id){
		$data = [];
		helper(['form']);
		//get site_id using SiteModel
		$model = new SiteModel();
		$site=$model->getRow($site_id);
		$session = session();
		if(empty($site)){
			$session->setFlashdata('error','Record not found.');
			return redirect()->to('/searchSite');
		}
		else
		{
			//delete record using SiteModel
			$model->delete($site_id);
			$session->setFlashdata('success','Successfully deleted.');
			return redirect()->to('/searchSite');
		}
		
	}

}
?>