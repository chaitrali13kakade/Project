<?php
  namespace App\Controllers;
  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
  use PhpOffice\PhpSpreadsheet\IOFactory;
  use App\Models\CompanyModel;
  use App\Models\TransactionModel;
  use App\Models\SiteModel;
  use App\Models\AttendanceModel;
  use App\Libraries\SallaryAttendanceReport;
    
  class ImportExcelController extends BaseController
  {
    function __contruct()
    {
      parent::__construct();/* call CodeIgniter's default Constructor */
      $this->load->model('SiteModel');/* load Model SiteModel */
      $this->load->model('CompanyModel');/* load Model CompanyModel*/
      $this->load->model('TransactionModel');/* load Model TransactionModel */
      $this->load->model('AttendanceModel');/* load Model AttendanceModel*/
    }
    public function ImportExcel()
    
    {
      $data = [];
      helper(['form']);//load the helper
      $session=session();//load the session
      
      //get site_name using SiteModel
      $model = new SiteModel();
      $result=$model->getSite();
      $data['site']=$result;
      
      //get year and month using AttendanceModel
      $atttendance_model=new AttendanceModel();
      $result_year =$atttendance_model->get_year();
      $data['year']=$result_year;
  
      $result_month =$atttendance_model->get_month();
      $data['month']=$result_month;
      //form input data
      $sheetname=$this->request->getPost('sheetname');
      $year=$this->request->getPost('year');
      $month=$this->request->getPost('month');
      $site_name = $this->request->getPost('site_name');
      $employee_total=$this->request->getPost('employee_total');
      $present_days=$this->request->getPost('present_days');
      $weekly_off=$this->request->getPost('weekly_off');
      $over_time=$this->request->getPost('over_time');
     
      // Validation
      $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      // Check form submit or not 
      if(isset($_FILES['upload_file']['name']) && in_array($_FILES['upload_file']['type'], $file_mimes))
      {
      //select file posted for inserting data
      $arr_file = explode('.', $_FILES['upload_file']['name']);
      //check file extension
      $extension = end($arr_file);
      if('csv' == $extension)
      {	// instantiate Csv
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
      } 
      else
      {	// instantiate Xlsx
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
      }
      //load only certain sheets from the file
      $reader->setLoadSheetsOnly($sheetname);
      $reader->setReadDataOnly( true );
      $spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
      // instantiate Spreadsheet
      //$allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null,true,true,true); // here i get all data from excel sheet
      
      $allDataInSheet = $spreadsheet->getActiveSheet()->toArray();//excel data in array format
      $highestrow = $spreadsheet->getActiveSheet()->getHighestRow();
      $highestcolumn = $spreadsheet->getActiveSheet()->getHighestColumn();
      $arrayCount=count($allDataInSheet);
      $data=array();

          // Skip first 4 row & check number of fields
          for($j=4; $j < $arrayCount; $j++)
          {
              if($j==4)
              {
              $emp_idcode_key = array_search('ID Code', $allDataInSheet[$j]);
              $emp_name_key = array_search ('Name of the Employee', $allDataInSheet[$j]);
              $emp_design_key = array_search ('Design', $allDataInSheet[$j]);
              $emp_present_days_key = array_search ('Present Days', $allDataInSheet[$j]);
              $emp_wo_key = array_search ('WO', $allDataInSheet[$j]);
              $emp_ot_key = array_search ('Extra Duty', $allDataInSheet[$j]);
              $emp_total_key = array_search ('Total', $allDataInSheet[$j]);
              // echo $emp_idcode_key;
              // echo $emp_name_key;
              // echo $emp_design_key;
              // echo $emp_present_days_key;
              // echo $emp_wo_key;
              
              }
              
              //echo"<pre>";
              $employee_id = $allDataInSheet[$j][$emp_idcode_key];
              $employee_name = $allDataInSheet[$j][$emp_name_key];
              $employee_designnation = $allDataInSheet[$j][$emp_design_key];
              $employee_present_days = $allDataInSheet[$j][$emp_present_days_key];
              $employee_weeklyoff = $allDataInSheet[$j][$emp_wo_key];
              $employee_extraduties = $allDataInSheet[$j][$emp_ot_key];
              $total = $allDataInSheet[$j][$emp_total_key];
              // echo $employee_id;
              
        if (strpos($employee_id, 'GW') === 0)
        {   
          $tmodel = new TransactionModel();
          //get employee_id using TransactionModel for checking employee_id is already exists or not
          $resultdata=$tmodel->query("select employee_id from tbl_transactionmaster where employee_id='$employee_id'");
          $arraydata=$resultdata->getNumRows();
          
          
              $data[]=array(
                'year'=>$year,
                'month'=>$month,
                'site_name'=> $site_name,
                'employee_id'=> $employee_id,
                'employee_name' =>$employee_name,
                'employee_designnation'=>$employee_designnation,
                'employee_present_days'=>$employee_present_days,
                'employee_weeklyoff' => $employee_weeklyoff,
                'employee_extraduties'=>$employee_extraduties,
                'total' => $total,
              );
            }
          }
            
            
      // echo"<pre>";
      // print_r($data);
          
      
      //array_column() function returns a single values from single column in the array
      $array_total = array_column($data, 'total');
      $array_present_days=array_column($data, 'employee_present_days');
      $array_weekly_off=array_column($data, 'employee_weeklyoff');
      $array_over_time=array_column($data, 'employee_extraduties');
      
      //array_sum() function returns the sum of all values in array
      $sum_total=array_sum($array_total); 
      $sum_prrsent_days=array_sum($array_present_days);  
      $sum_weekly_off=array_sum($array_weekly_off); 
      $sum_over_time=array_sum($array_over_time); 
      
      if($arraydata === 0)
      {
        //echo "not exists";
        if($sum_total == $employee_total && $sum_prrsent_days == $present_days && $sum_weekly_off == $weekly_off && $sum_over_time == $over_time)
        {
          //Calling modal function to insert into table
          $inserdata=$tmodel->insert_data($data);
          $session->setFlashdata('success','Excel File Imported Successfuly');
          return redirect()->to('/ImportReport/importexcel'); 
        }
        else
        {
          $session->setFlashdata('error','There is difference in total. Please kindly Check...');
        return redirect()->to('/ImportReport/importexcel');
        }
          
      }
      else
      {
        $session->setFlashdata('error','Data Already Exist.');
        return redirect()->to('/ImportReport/importexcel'); 
      }
    }
    

      //load the view/templates/header.php with $data
      echo view('templates/header', $data);
      //load the view/ImportReport/importexcel.php 
      echo view('ImportReport/importexcel');
      //load the view/templates/footer.php 
      echo view('templates/footer');
    }

    public function ViewReport(){

      $data = [];
      helper(['form']);
      //get attendance report using TransactionModel
      $model = new TransactionModel();
      $data['excelreport']=$model->getExcelData();
      //load the view/templates/header.php with $data
      echo view('templates/header',$data);
      //load the view/ImportReport/importexcel.php 
      echo view('ImportReport/View-Report');
      //load the view/templates/footer.php 
      echo view('templates/footer');
    }

    public function GenearteAttendanceReport()
    {
      $data = [];
      helper(['form']);
      $attendance_excel = new SallaryAttendanceReport();
			return $attendance_excel->attendanceExportToExcel();
    }  
  }
?>