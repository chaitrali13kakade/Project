<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		/** 
                Set the margins of the pdf page to 0, so the footer and the header
                can be of the full height and width !
                **/
                @page {
                	margin: 0cm 0cm;
                }
                /** Define now the real margins of every pdf page in the PDF **/
                body {
                	margin-top: 2cm;
                	margin-left: 2cm;
                	margin-right: 2cm;
                	margin-bottom: 2cm;
                }
                /** Define the header rules **/
                header {
                	position: fixed;
                	top: 0cm;
                	left: 0cm;
                	right: 0cm;
                	height: 2cm;
                	/** Extra personal styles **/
                	background-color: #0b395b;
                	color: white;
                	text-align: center;
                	line-height: 1.5cm;
                }
                /** Define the footer rules **/
                footer {
                	position: fixed; 
                	bottom: 0cm; 
                	left: 0cm; 
                	right: 0cm;
                	height: 2cm;
                	/** Extra personal styles **/
                	background-color: #0b395b;
                	color: white;
                	text-align: center;
                	line-height: 1.5cm;
                }
                table {
                    font-family: arial, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                    margin-top: 25px;
                }

                td, th {
                    border: 1px solid black;
                    text-align: left;
                }
            </style>

        </head>
        <header>
        	Site Report
        </header>
        <footer>
        	All Rights Reserved. Copyright © <?php echo date("Y");?> 
        </footer>
        <main>
        	<body>
        		<div class="container mt-2 ">
        			<div class="container-fluid">
        				<div class="card-body">
        					<table id="siteData" class="table table-bordered ">
        						<tr>
        							<th>Sr No</th>
        							<th>Company Id</th>
        							<th>Site ID </th>
        							<th>Site Name</th>
        							<th>Status</th>
        						</tr>
        						<?php $i=1; foreach($site as $val):  ?>
        						<tr>
        							<td><?php echo $i++ ?></td>
        							<td><?php echo $val['id'] ?></td>
        							<td><?php echo $val['site_sid'] ?></td>
        							<td><?php echo $val['site_name']?></td>
        							<td> <?php echo $val['status']?></td>
        						</tr>
        					<?php endforeach; ?>
        				</table>
        			</div>
        		</div>
        	</div>
        </body>
    </main>
