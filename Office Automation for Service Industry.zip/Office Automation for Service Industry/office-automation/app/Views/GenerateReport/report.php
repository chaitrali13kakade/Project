<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Generate Report In PDF/Excel</div>

						</div>
					</div>
					<hr>
					<form class="" action="<?= base_url('ReportController/ReportGeneration')?>" method="post" >
						<div class="row">
							<div class="form-group">
								<label for="">Generate Report In PDF/Excel</label><br>
								<select class="form-select" aria-label="Default select example" name="selectFile" id="selectFile" required>
									<option selected>-- Select File --</option>
									<option value="company" id="company" name="company">Company</option>
									<option value="site" id="site">Site</option>
									<option value="mapform" id="mapform">Map Form</option>
									<!-- <option value="allfiles" id="allfiles">All Files</option> -->
								</select>
								<br>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="radioButton" id="pdf" value="pdf" checked="checked">
									<label class="form-check-label" for="inlineRadio1">PDF</label>
								</div>
								
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="radioButton" id="excel" value="excel">
									<label class="form-check-label" for="inlineRadio2">Excel</label>
								</div>

								<div class="row">
									<div class="col-12 col-sm-4">
										<button type="submit" class="btn btn-primary btn-sm" name="download" value="download">Download</button>
									</div>
								</div>

									
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
