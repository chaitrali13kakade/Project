<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>"> -->
</head>
<body>
	<div class="container-fluid shadow-sm">
		<div class="container pb-2 pt-2">
			<div class="text-black h4">Company Details</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="container mt-4">
			</div>
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-3 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
					</div>
					<div class="container mt-2">
						<div class="row">							
							<div class="col-md-12 text-right">
								<a href="/searchCompany" class="btn btn-primary btn-sm"> </i>Back</a>
							</div>
						</div>
					</div>
					<hr>
					<?php if (session()->get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?= session()->get('success') ?>
					</div>
					<?php endif; ?>
					<?php if (session()->get('error')): ?>
					<div class="alert alert-danger" role="alert">
						<?= session()->get('error') ?>
					</div>
					<?php endif; ?>
					<form class="" action="" method="post">
						
						<div class="row">
							<div class="form-group">
								<label for="company_id">Enter Company Id </label>
								<input type="text" name="company_id" class="form-control" id="company_id" value="<?php echo set_value('company_id',$company['company_id']) ?>">
							</div>
						</div>

						<div class="row">
							<div class="form-group">
								<label for="company_name">Enter Company Name</label>
								<input type="text" name="company_name" class="form-control" id="company_name" value="<?php echo set_value('company_name',$company['company_name']) ?>">
							</div>
						</div>
							<div class="form-group">
							<label for="status">Enter Company Status</label><br>
								<input id="status" name="status" type="radio" value="1" checked="checked" >
								<label for="status" class="" value="">Active</label>
								<input id="status" name="status" type="radio" value="0" >
								<label for="status" class="" value="">Inactive</label>	
						</div>
						</div><br>
						<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-12 col-sm-4">
								<button type="submit" class="btn btn-primary">Update</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>