<!DOCTYPE html>
<html>
<head>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="/assets/css/style.css">

</head>

<body style="background-color:#17a2b8;">
    <div id="register">
        <h3 class="text-center text-white pt-5">Registration form</h3>
        <div class="container">
            <div id="register-row" class="row justify-content-center align-items-center">
                <div id="register-column" class="col-md-6">
                    <div id="register-box" class="col-md-12">
                        <form id="register-form" class="form" action="/register" method="post">
                            <h3 class="text-center text-info">Registration</h3>
                            <div class="form-group">
								<label for="firstname">Firstname</label>
								<input type="text" name="firstname" class="form-control" id="firstname" value="<?php echo set_value('firstname')?>">
                            </div>
                            <div class="form-group">
								<label for="lastname">Lastname</label>
								<input type="text" name="lastname" class="form-control" id="lastname" value="<?php echo set_value('lastname')?>">
                            </div>
							<div class="form-group">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" id="username" value="<?php echo set_value('useranme')?>">
                            </div>
							<div class="form-group">
							<label for="password">Password</label>
							<input type="password" name="password" class="form-control" id="password" value="">
                            </div>
                            <div class="form-group">
								<div class="row">
									<div class="col-12 col-sm-4">
										<button type="submit" class="btn btn-primary">Submit</button>
									</div>
								</div>
                            </div>
							<!-- <div id="register-link" class="text-right">
								<a href="/">Already have an account...</a>
							</div>                             -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

