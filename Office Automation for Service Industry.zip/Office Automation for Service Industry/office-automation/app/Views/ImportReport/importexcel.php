<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
  <!-- CONTAINER START -->
  <div class="container">
    <div class="row">
      <div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
        <div class="container">
          <div class="container-fluid shadow-sm">
            <div class="container pb-2 pt-2">
              <div class="text-black h4"></div>

            </div>
          </div><hr>
          <?php if (session()->get('success')): ?>
          <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
          </div>
          <?php endif; ?>
          <?php if (session()->get('error')): ?>
              <div class="alert alert-danger" role="alert">
                <?= session()->get('error') ?>
              </div>
            <?php endif; ?>

           <!-- FORM START-->
           
          <!-- <form action="<?php echo base_url('ImportController/ImportExcel');?>" enctype="multipart/form-data" method="post"> -->
          <form action="<?php echo base_url('ImportExcelController/ImportExcel');?>" enctype="multipart/form-data" method="post">
            <div class="form-row">
            <div class="form-group col-md-6">
            <label for="sel1">Select Year</label>
              <select class="form-select"  name="year" id="year">
                <option>Select Year</option>
               
                <?php if(!empty($year)) {
                foreach($year as $val)
                {

                  echo '<option name="'.  set_value('year', $val['year']).'" value="'.  set_value('year', $val['year']).'">'.$val['year'].'</option>';
                }
              }
              ?>

            </select> 
            </div>
            <div class="form-group col-md-6">
          
              <label for="sel1">Select Month</label>
              <select class="form-select"  name="month" id="month" >
                <option >Select Month</option>
                
                <?php if(!empty($month)) {
                foreach($month as $val)
                {

                  echo '<option name="'.  set_value('month', $val['month']).'" value="'.  set_value('month', $val['month']).'">'.$val['month'].'</option>';
                }
              }
              ?>

            </select> 
          
          </div>
            </div>

            <div class="form-group">
              <label for="sel1">Select Site Name</label>
              <select class="form-select" aria-label="Default select example" name="site_name" id="site_name" >
                <option selected>Select Site name</option>
                
                <?php if(!empty($site)) {
                foreach($site as $val)
                {

                  echo '<option name="'.  set_value('site_name', $val['site_name']).'" value="'.  set_value('site_name', $val['site_name']).'">'.$val['site_name'].'</option>';
                }
              }
              ?>

            </select> 
          </div>
          
            <div class="form-group">
              <label for="company_name">Enter Sheet Name</label>
              <input type="text" name="sheetname" class="form-control" id="sheetname" value="" required>
            </div>
            <div class="form-group">
            <label for="sel1">Select Excel File</label>
            <div class="form-group">
              <input type="file" name="upload_file" class="form-control" placeholder="Enter Name" id="upload_file" required>
            </div>
          </div>
            <div class="form-group">
              <label for="company_name">Enter Present Days</label>
              <input type="text" class="form-control" name ="present_days" id="present_days" onkeyup="sum();" return false; placeholder="Present Days" required />
            </div>
            

            <div class="form-group">
              <label for="company_name">Enter Weekly Off</label>
              <input type="text" class="form-control" name="weekly_off" id="weekly_off" onkeyup="sum();" return false; placeholder="Weekly Off"  required />
            </div>

            <div class="form-group">
              <label for="company_name">Enter Over Time</label>
              <input type="text" class="form-control"  name="over_time" id="over_time" onkeyup="sum();" return false; placeholder="Over Time" required />
            </div>

          <div class="form-group">
            <label for="company_name">Total</label>
            <input type="text" class="form-control" name="employee_total" id="employee_total" return false; placeholder="Total" />
          </div>
          


          <?php if (isset($validation)): ?>
          <div class="col-12">
            <div class="alert alert-danger" role ="alertalert">
              <?= $validation->listErrors() ?>
            </div>
          </div>
          <?php endif; ?>

          <div class="form-group">
            <button type="submit" class="btn btn-primary">Import</button>
          </div>

        </form>
        <!-- FORM END -->
      </div>
    </div>
  </div>
</div> 
<!-- CONTAINER START -->
</body>
<script type="text/javascript">

  function sum()
  {
    var w = document.getElementById('present_days').value || 0;
    var x = document.getElementById('weekly_off').value || 0;
    var y = document.getElementById('over_time').value || 0;
    var z=parseFloat(w)+parseFloat(x)+parseFloat(y);
    document.getElementById('employee_total').value=parseFloat(z);
  }       
</script>
</html>