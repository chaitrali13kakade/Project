<!DOCTYPE html>
<html>
<head>
  <title></title>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>

<div class="bg"></div>	
<div class="container">
	<div class="row">
		<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
			<div class="container">
				<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Login</div>

						</div>
					</div>
				<hr>
				<?php if (session()->get('success')): ?>
          <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
          </div>
        <?php endif; ?>

				<form class="" action="/" method="post">
					<div class="row">

					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" name="username" class="form-control" id="username" value="<?= set_value('useranme')?>">
					</div>

					<div class="form-group">
						<label for="password">Password</label>
						<input type="password" name="password" class="form-control" id="password" value="">
					</div>	
					</div><br>

					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>
          
					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Login</button>
						</div>

						<div class="col-12 col-sm-8 test-right">
							<a href="/register">Dont have an account?</a>
						</div>
          </div>

				</form>
			</div>
		</div>
	</div>
</div> 
