<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
			<div class="container">
				<h3><?= $user['firstname'].' '.$user['lastname'] ?></h3>
				<hr>
				<?php if (session()->get('success')): ?>
          <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
          </div>
        <?php endif; ?>


				<form class="" action="/profile" method="post">
					<div class="row">
						<div class="form-group">
							<label for="username">Firstname</label>
							<input type="text" name="firstname" class="form-control" id="firstname" value="<?= set_value('firstname', $user['firstname'])?>">
						</div>

						<div class="form-group">
							<label for="password">Lastname</label>
							<input type="text" name="lastname" class="form-control" id="lastname" value="<?= set_value('lastname', $user['lastname'])?>">
						</div>	
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" id="username" value="<?= set_value('useranme', $user['username'])?>">
						</div>

						<div class="form-group">
							<label for="password">Password</label>
							<input type="password" name="password" class="form-control" id="password" value="">
						</div>
					</div><br>
					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>


					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Update</button>
						</div>
					</div>



				</form>

			</div>
		</div>
	</div>

</div>