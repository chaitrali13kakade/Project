<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
        <div class="container">
          <div class="container-fluid shadow-sm">
            <div class="container pb-2 pt-2">
              <div class="text-black h4">Attendance Master</div>

            </div>
          </div><hr>
          <?php if (session()->get('success')): ?>
          <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
          </div>
        <?php endif; ?>
          <form action="" method="post">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="inputEmail4">Year</label>
                <input type="number" class="form-control" id="datepicker" min="1900" max="2099" step="1" value="2021" name="year">
              </div>
              <div class="form-group col-md-6">
                <label for="inputPassword4">Month</label>
                <select name="month" value="" class="form-select" aria-label="Default select example">
                  <option selected>-- Select Month --</option>
                  <option value='01'>January</option>
                  <option value='02'>February</option>
                  <option value='03'>March</option>
                  <option value='04'>April</option>
                  <option value='05'>May</option>
                  <option value='06'>June</option>
                  <option value='07'>July</option>
                  <option value='08'>August</option>
                  <option value='09'>September</option>
                  <option value='10'>October</option>
                  <option value='11'>November</option>
                  <option value='12'>December</option>
                </select>
                
              </div>
            </div>
            <div class="form-group">
              <label for="inputAddress">Select working Days</label>
              <input type="number" class="form-control" id="working_days" name="working_days" max="100000" min="1" step="1" value="1" placeholder="">
            </div>

            <div class="form-group">
             <label for="">Select Service</label>

             <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="service" id="security" value="security" checked="checked">
              <label class="form-check-label" for="inlineRadio1">Security</label>
            </div>

            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="service" id="facility" value="facility">
              <label class="form-check-label" for="inlineRadio2">Facility</label>
            </div>

            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="service" id="manpower" value="manpower">
              <label class="form-check-label" for="inlineRadio2">Man Power</label>
            </div>   
          </div>

          <div class="form-group">
            <label for="inputAddress">National Holidays</label>
            <input type="number" class="form-control" id="national_holiday" name="no_of_nationalholidays" max="100000" min="0" step="1" value="0" placeholder="">
          </div>


          <?php if (isset($validation)): ?>
            <div class="col-12">
              <div class="alert alert-danger" role ="alertalert">
                <?= $validation->listErrors() ?>
              </div>
            </div>
          <?php endif; ?>

          <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          
        </form>
      </div>
    </div>
  </div>
</div> 
</body>
</html>