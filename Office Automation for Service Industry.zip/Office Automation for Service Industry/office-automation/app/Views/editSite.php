<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Site Details</div>

						</div>
					</div>
					<div class="container mt-2">
						<div class="row">
							
							<div class="col-md-12 text-right">

								<a href="/searchSite" class="btn btn-primary">Back</a>
							</div>
						</div>
					</div>

					<hr>
					<?php if (session()->get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?= session()->get('success') ?>
					</div>
				<?php endif; ?>
				<?php if (session()->get('error')): ?>
					<div class="alert alert-danger" role="alert">
						<?= session()->get('error') ?>
					</div>
				<?php endif; ?>
					<form class="" action="" method="post">
						<div class="form-group">
							<label for="sel1">Select Company Name</label>
							<select class="form-select" aria-label="Default select example" name="id[]" value="">
								<option selected>select company name</option>
								<?php foreach($company->getResult() as $val): ?>
									
									<option value="<?php echo $val->id ?>"><?php echo $val->company_name ?></option>
								
								<?php endforeach; ?>								
							</select>
						</div>
						
						
						<div class="row">
							<div class="form-group">
								<label for="site">Enter Site Id </label>
								<input type="text" name="site_sid" class="form-control" id="site_sid" value="<?= set_value('site_sid', $site['site_sid'])?>">
							</div>
						</div>

						<div class="row">
							<div class="form-group">
								<label for="site">Enter Site Name</label>
								<input type="text" name="site_name" class="form-control" id="site_name" value="<?= set_value('site_name', $site['site_name'])?>">
							</div>
						</div>

						<div class="form-group">
							<label for="company_name">Site Status</label><br>
							<input id="status" name="status" type="radio" value="1" checked="checked" >
							<label for="status" class="" value="">Active</label>
							<input id="status" name="status" type="radio" value="0" >
							<label for="status" class="" value="">Inactive</label>		
						</div>
					</div>


					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>

					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Update</button>
						</div>

						

					</div>

				</form>

			</div>
		</div>
	</div>
