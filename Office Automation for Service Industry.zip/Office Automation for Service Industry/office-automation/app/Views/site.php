<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/js/jquery-3.6.0.min.js');?>">
	
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Site Details</div>

						</div>
					</div>

					<hr>
					<?php if (session()->get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?= session()->get('success') ?>
					</div>
				<?php endif; ?>
				<?php if (session()->get('error')): ?>
				<div class="alert alert-danger" role="alert">
					<?= session()->get('error') ?>
				</div>
			<?php endif; ?>
					<form class="" action="" method="post" name="createSite" id="createSite">
						<div class="form-group">
							<label for="sel1">Select Company Name</label>
							<select class="form-select" type="hidden" aria-label="Default select example" name="id" id="id">
								<option selected>select company name</option>
								
								<?php if(!empty($company)) {
								foreach($company as $val)
								{
									echo "<option value='".$val['id']."'>".$val['company_name']."\t\t".$val['company_id']."</option>";
								}
							}
								?>
															
							</select> 
						</div>
						
						
						<div class="row">
							<div class="form-group">
								<label for="site">Enter Site Id </label>
								<input type="text" name="site_sid" class="form-control" id="site_sid" value="<?= set_value('site_sid')?>">
							</div>
						</div>

						<div class="row">
							<div class="form-group">
								<label for="site">Enter Site Name</label>
								<input type="text" name="site_name" class="form-control" id="site_name" value="<?= set_value('site_name')?>">
							</div>
						</div>

						<div class="form-group">
							<label for="company_name">Site Status</label><br>
							<input id="status" name="status" type="radio" value="1" checked="checked" >
							<label for="status" class="" value="">Active</label>
							<input id="status" name="status" type="radio" value="0" >
							<label for="status" class="" value="">Inactive</label>		
						</div>
					</div>


					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>

					<div class="row">
						<div class="col-12 col-sm-4">
							<!-- <input type="button" class="btn btn-primary" value="save data" id="butsave"> -->
							<button type="submit" class="btn btn-primary">Save</button>
						</div>

						<div class="col-12 col-sm-8 test-right">
							<a href="/searchSite">List Site</a>
						</div>

					</div>

				</form>

			</div>
		</div>
	</div>
	
</div></body>
<!-- <script  src="<?php echo base_url('assets/js/jquery-3.6.0.min.js');?>"></script>
<script>
	$("#createSite").submit(function(event){
		event.preventDefault();
		//alert();
		$.ajax({
			url : '<?php echo base_url('MainController/site')?>',
			type : 'post',
			data : $(this).serializeArray(),
			dataType : 'json',
			success : function(response){
				console.log(response)
			}
		})
	});
</script>  -->


