<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Custom fonts for this template -->
    <link href="<?php echo base_url('assets_new/vendor/fontawesome-free/css/all.min.css');?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('assets_new/css/sb-admin-2.min.css');?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets_new/css/style.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">

    <!-- Custom styles for this page -->
    <link href="<?php echo base_url('assets_new/vendor/datatables/dataTables.bootstrap4.min.css');?>" rel="stylesheet">
    
<style>

</style>
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Begin Page Content -->
                <div class="container-fluid">
                	
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Site Details</h1>					
                    <!-- DataTales Example -->
                        <?php if (session()->get('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?= session()->get('success') ?>
                          </div>
                        <?php endif; ?>

                        <?php if (session()->get('error')): ?>
                          <div class="alert alert-danger" role="alert">
                            <?= session()->get('error') ?>
                          </div>
                        <?php endif; ?>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"></h6>
                            <span class="float-right">
                            <a href="/site" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i>Create Site Record</a>
                            </span>
                        </div>	
                        				
                        <div class="card-body">
                        <div class="row">
                          <label for="entries" class="col-md-2 mt-2 control-label">Entries:</label>
                          <div class="col-md-4 mt-2">							
                            <div class="num_rows ">
                              <div class="form-group"> 	
                                <!--		Show Numbers Of Rows 		-->
                                <select class  ="form-control" name="state" id="maxRows">									
                                  <option value="10">10</option>
                                  <option value="15">15</option>
                                  <option value="20">20</option>
                                  <option value="50">50</option>
                                  <option value="70">70</option>
                                  <option value="100">100</option>
                                  <option value="5000">Show ALL Rows</option>
                                </select>											
                              </div>
                            </div>
                          </div>
                          <label for="search" class="col-md-2 mt-2 control-label">Search Here:</label>
                          <div class="col-md-4">
                            <div class="tb_search">
                              <input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control mt-2">
                            </div>
                          </div>
                        </div>                        
                            <div class="table-responsive">
                                <table class="table table-bordered" id="table-id" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                          <th>Sr No</th>                
                                          <th>Company Id</th>
                                          <th>Site Id</th>
                                          <th>Site name</th>
                                          <th>Status</th>
                                          <th width="160">Action</th>
                                        </tr>
                                    </thead>                                    
                                    <?php if(is_array($site)): ?>
                                    <?php $i=1; foreach($site as $val):  ?>
                                    <tr>
                                      <td><?php echo $i++ ?></td>
                                      <td><?php echo $val['id'] ?></td>
                                      <td><?php echo $val['site_sid']?></td>                
                                      <td><?php echo $val['site_name'] ?></td>
                                      <td> 
                                        <?php 
                                        if ($val['status'] ==1) {?> 
                                          <a href="" class="btn btn-success btn-sm">Active</a>
                                        <?php } 
                                        else {?> 
                                          <a href="" class="btn btn-danger btn-sm">Inactive</a>
                                        <?php } ?> 
                                      </td>

                                      <td>
                                        <a href="<?php echo base_url('SiteController/editSite/' .$val['site_id']);?>" class="btn btn-primary btn-sm"><i class="far fa-edit" aria-hidden="true"></i>Edit</a>
                                        <a href="#" onclick="deleteConfirm('<?php echo $val['site_id']; ?>');" class="btn btn-danger btn-sm"><i class="fa fa-trash" aria-hidden="true"></i>Delete</a>
                                      </td>

                                    </tr>

                                  <?php endforeach; ?>
                                  <?php endif;?>
                                </table>
								<!--		Start Pagination -->
								<div class='pagination-container'>
									<nav>
									<ul class="pagination">
									<!--	Here the JS Function Will Add the Rows -->
									</ul>
									</nav>
								</div>
							<div class="rows_count">Showing 11 to 20 of 91 entries</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->           
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
    <!-- Page level plugins -->
    <script src="<?php echo base_url('asstes_new/vendor/datatables/jquery.dataTables.min.js');?>"></script>
    <script src="<?php echo base_url('asstes_new/vendor/datatables/dataTables.bootstrap4.min.js');?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo base_url('asstes_new/js/demo/datatables-demo.js');?>"></script>
    <script>

    function deleteConfirm(id){
        //alert(id);
        if(confirm("Are You sure you want to delete?")){
          window.location.href='<?php echo base_url('SiteController/deleteSite/')?>/'+id;
        }
      }

    getPagination('#table-id');
	$('#maxRows').trigger('change');
	function getPagination (table){

		  $('#maxRows').on('change',function(){
		  	$('.pagination').html('');						// reset pagination div
		  	var trnum = 0 ;									// reset tr counter 
		  	var maxRows = parseInt($(this).val());			// get Max Rows from select option
        
		  	var totalRows = $(table+' tbody tr').length;		// numbers of rows 
			 $(table+' tr:gt(0)').each(function(){			// each TR in  table and not the header
			 	trnum++;									// Start Counter 
			 	if (trnum > maxRows ){						// if tr number gt maxRows
			 		
			 		$(this).hide();							// fade it out 
			 	}if (trnum <= maxRows ){$(this).show();}// else fade in Important in case if it ..
			 });											//  was fade out to fade it in 
			 if (totalRows > maxRows){						// if tr total rows gt max rows option
			 	var pagenum = Math.ceil(totalRows/maxRows);	// ceil total(rows/maxrows) to get ..  
			 												//	numbers of pages 
			 	for (var i = 1; i <= pagenum ;){			// for each page append pagination li 
			 	$('.pagination').append('<li data-page="'+i+'">\
								      <span>'+ i++ +'<span class="sr-only">(current)</span></span>\
								    </li>').show();
			 	}											// end for i 
     
         
			} 												// end if row count > max rows
			$('.pagination li:first-child').addClass('active'); // add active class to the first li 
        
        
        //SHOWING ROWS NUMBER OUT OF TOTAL DEFAULT
       showig_rows_count(maxRows, 1, totalRows);
        //SHOWING ROWS NUMBER OUT OF TOTAL DEFAULT

        $('.pagination li').on('click',function(e){		// on click each page
        e.preventDefault();
			var pageNum = $(this).attr('data-page');	// get it's number
			var trIndex = 0 ;							// reset tr counter
			$('.pagination li').removeClass('active');	// remove active class from all li 
			$(this).addClass('active');					// add active class to the clicked 
        
        
        //SHOWING ROWS NUMBER OUT OF TOTAL
       showig_rows_count(maxRows, pageNum, totalRows);
        //SHOWING ROWS NUMBER OUT OF TOTAL
        
        
        
	$(table+' tr:gt(0)').each(function(){			// each tr in table not the header
		trIndex++;									// tr index counter 
		// if tr index gt maxRows*pageNum or lt maxRows*pageNum-maxRows fade if out
			if (trIndex > (maxRows*pageNum) || trIndex <= ((maxRows*pageNum)-maxRows)){
				$(this).hide();		
			}else {$(this).show();} 				//else fade in 
				 }); 								// end of for each tr in table
			});										// end of on click pagination list
		});
													// end of on select change 		 
													// END OF PAGINATION     
	}	


			

// SI SETTING
$(function(){
	// Just to append id number for each row  
default_index();
					
});

//ROWS SHOWING FUNCTION
function showig_rows_count(maxRows, pageNum, totalRows) {
   //Default rows showing
        var end_index = maxRows*pageNum;
        var start_index = ((maxRows*pageNum)- maxRows) + parseFloat(1);
        var string = 'Showing '+ start_index + ' to ' + end_index +' of ' + totalRows + ' entries';               
        $('.rows_count').html(string);
}


// All Table search script
function FilterkeyWord_all_table() {
  
// Count td if you want to search on all table instead of specific column

  var count = $('.table').children('tbody').children('tr:first-child').children('td').length; 

        // Declare variables
  var input, filter, table, tr, td, i;
  input = document.getElementById("search_input_all");
  var input_value =     document.getElementById("search_input_all").value;
        filter = input.value.toLowerCase();
  if(input_value !=''){
        table = document.getElementById("table-id");
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and hide those who don't match the search query
        for (i = 1; i < tr.length; i++) {
          
          var flag = 0;
           
          for(j = 0; j < count; j++){
            td = tr[i].getElementsByTagName("td")[j];
            if (td) {
             
                var td_text = td.innerHTML;  
                if (td.innerHTML.toLowerCase().indexOf(filter) > -1) {
                //var td_text = td.innerHTML;  
                //td.innerHTML = 'shaban';
                  flag = 1;
                } else {
                  //DO NOTHING
                }
              }
            }
          if(flag==1){
                     tr[i].style.display = "";
          }else {
             tr[i].style.display = "none";
          }
        }
    }else {
      //RESET TABLE
      $('#maxRows').trigger('change');
    }
}
</script>
</body>
</html>