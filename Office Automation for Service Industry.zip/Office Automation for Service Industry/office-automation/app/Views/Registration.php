<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets_new/css/style.css');?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	
</head>
<body>
	
	<div class="container">
		<h2>Registration Form</h2>
		
		<form class="" action="/register" method="post">
					<div class="row">
						<div class="form-group">
							<label for="username">Firstname</label>
							<input type="text" name="firstname" class="form-control" id="firstname" value="<?= set_value('firstname')?>">
						</div>

						<div class="form-group">
							<label for="password">Lastname</label>
							<input type="text" name="lastname" class="form-control" id="lastname" value="<?= set_value('lastname')?>">
						</div>	
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" id="username" value="<?= set_value('useranme')?>">
						</div>

						<div class="form-group">
							<label for="password">Password</label>
							<input type="password" name="password" class="form-control" id="password" value="">
						</div>
					</div><br>
					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>


					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
		</form>
	</div>
</body>
</html>
