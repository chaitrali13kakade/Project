<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Custom fonts for this template -->
    <link href="<?php echo base_url('assets_new/vendor/fontawesome-free/css/all.min.css');?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('assets_new/css/sb-admin-2.min.css');?>" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
	<div class="container-fluid shadow-sm">
		<div class="container pb-2 pt-2">
			<div class="text-black h4">Company Details</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="container mt-4">

			</div>
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-3 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Company</div>

						</div>
					</div>
					<hr>
					<?php if (session()->get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?= session()->get('success') ?>
					</div>
				<?php endif; ?>
				<form class="" action="/company" method="post">
					<div class="row">
						<div class="form-group">
							<label for="company_name">Enter Company Id</label>
							<input type="text" name="company_id" class="form-control" id="company_id" value="">
						</div>

						<div class="form-group">
							<label for="company_name">Enter Company Name</label>
							<input type="text" name="company_name" class="form-control" id="company_name" value="">
						</div>

						<div class="form-group">
							<label for="company_name">Enter Company Status</label><br>
							<input id="status" name="status" type="radio" value="1" checked="checked" >
							<label for="status" class="" value="">Active</label>
							<input id="status" name="status" type="radio" value="0" >
							<label for="status" class="" value="">Inactive</label>	
						</div>
					</div><br>

					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>

					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Save</button>
						</div>

						<div class="col-12 col-sm-8 test-right">
							<a href="/searchCompany">List Company</a>
						</div>

					</div>
				</div>
			</form>

		</div>
	</div>
</div>
</div>