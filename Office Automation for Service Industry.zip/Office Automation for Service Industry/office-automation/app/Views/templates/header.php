<!DOCTYPE html>
<html>
<head>
	<title></title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
	<link rel="stylesheet" type="text/css" href="/assets/css/style.css">

  <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets_new/css/style.css');?>"> -->
  

</head>
<body>
  <?php
      $uri = service('uri');
     ?>

	

  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <a class="navbar-brand" href="#">Office Automation</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarsExample03">
      <?php if(session()->get('isLoggedIn')): ?>
        <ul class="navbar-nav mr-auto">
          <li class="nav-item  <?= ($uri->getSegment(1) == 'dashboard' ? 'active' : null) ?>" >
            <a class="nav-link" href="/dashboard">Dashboard</a>
          </li>
          <li class="nav-item  <?= ($uri->getSegment(1) == 'profile' ? 'active' : null) ?>">
            <a class="nav-link" href="/profile">Profile</a>
          </li>
          <li class="nav-item  <?= ($uri->getSegment(1) == 'searchCompany' ? 'active' : null) ?>">
              <a class="nav-link" href="/searchCompany">Company</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'searchSite' ? 'active' : null) ?>">
              <a class="nav-link" href="/searchSite">Site</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'searchMappingform' ? 'active' : null) ?>">
              <a class="nav-link" href="/searchMappingform">Mapping Form</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'GenerateReport/report' ? 'active' : null) ?>">
              <a class="nav-link" href="/GenerateReport/report">Report</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'AttendanceForm' ? 'active' : null) ?>">
              <a class="nav-link" href="/AttendanceForm">Attendance</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'ImportReport/importexcel' ? 'active' : null) ?>">
              <a class="nav-link" href="/ImportReport/importexcel">Import Excel</a>
            </li>
            <li class="nav-item  <?= ($uri->getSegment(1) == 'ImportReport/View-Report' ? 'active' : null) ?>">
              <a class="nav-link" href="/ImportReport/View-Report">View Report</a>
            </li>
        </ul>
        <ul class="navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="/logout">Logout</a>
          </li>
        </ul>
        <?php else: ?>
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active <?= ($uri->getSegment(1) == '' ? 'active' : null) ?>">
            <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item  <?= ($uri->getSegment(1) == '' ? 'active' : null) ?>">
              <a class="nav-link" href="/register">Register</a>
          </li>
           
        </ul>
        <?php endif; ?>
      </div>
    </nav>

