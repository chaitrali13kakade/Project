<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
	<div class="container-fluid shadow-sm">
		<div class="container pb-2 pt-2">
			<div class="text-black h4">Editable Form</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="container mt-4">

			</div>
			<div class="col-12 col-sm8- offset-sm-2 col-md-6 offset-md-3 mt-3 pt-3 bg-white from-wrapper">
				<div class="container">
					<div class="container-fluid shadow-sm">
						<div class="container pb-2 pt-2">
							<div class="text-black h4">Mapping Form</div>

						</div>
					</div>
					<hr>
					<?php if (session()->get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?= session()->get('success') ?>
					</div>
				<?php endif; ?>
				<form class="" action="" method="post">
					<div class="row">
						<div class="form-group">
							<label for="sel1">Select Site Name</label>
							<select class="form-select" aria-label="Default select example" name="site_id" id="site_id">
								<option selected>Select Site name</option>
								
								<?php if(!empty($site)) {
								foreach($site as $val)
								{
									
									echo '<option name="'.	set_value('site_id', $val['site_id']).'" value="'.	set_value('site_id', $val['site_id']).'">'.$val['site_name'].'</option>';
								}
							}
								?>
															
							</select> 
						</div>

						<div class="form-group">
							<label for="company_name">Payroll Name</label>
							<input type="text" name="payroll_name" class="form-control" id="payroll_name" value="">
						</div>
						<div class="form-group">
							<label for="company_name">Billing  Name</label>
							<input type="text" name="billing_name" class="form-control" id="billing_name" value="">
						</div>

						
					</div><br>

					<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role ="alertalert">
								<?= $validation->listErrors() ?>
							</div>
						</div>
					<?php endif; ?>

					<div class="row">
						<div class="col-12 col-sm-4">
							<button type="submit" class="btn btn-primary">Save</button>
						</div>


					</div>
				</div>
			</form>

		</div>
	</div>
</div>
</div>