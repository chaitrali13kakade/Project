<?php
namespace App\Libraries;
use App\Models\SiteModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class SiteExcel
{
	public function createSiteExcel()
	{
		$data = [];
		helper(['form']);
		//get site details using SiteModel
		$model = new SiteModel();
		$result=$model->findAll();
		//set excel file name
		$file_name = 'SiteReport.xlsx';
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
		$spreadsheet->getActiveSheet()->setCellValue('A1',"Site Report");
		$spreadsheet->getActiveSheet()->mergeCells("A1:E1");
		$spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
		$spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
				
		// add style to the header
		$styleArray = [
			'font'=> [
				'color' => ['rgb' => 'FFFFFF'],
				'bold' =>true,
				'size' => 11
			],
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'ff4d4d'],
			],
			'alignment' => [
				'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
			],
			'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],	
		];
		//add style to even row
		$evenRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'd9d9d9'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];
		//add style to odd row
		$oddRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'a6a6a6'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' =>Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];
		//applying style to header
		$spreadsheet->getActiveSheet()->getStyle('A2:E2')->applyFromArray($styleArray);
		// auto fit column to content
		foreach(range('A', 'E
			') as $columnID) {
			$spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		// Set cell  with a string value
		$sheet->setCellValue('A2', 'Sr No');
		$sheet->setCellValue('B2', 'Company Id');
		$sheet->setCellValue('C2', 'Site Id');
		$sheet->setCellValue('D2', 'Site Name');
		$sheet->setCellValue('E2', 'Site Status');
		$sno=1;
		$count = 3;
		//Fill the table data
		foreach($result as $row)
		{	
			$sheet->setCellValue('A' . $count, $sno++);
			$sheet->setCellValue('B' . $count, $row['id']);
			$sheet->setCellValue('C' . $count, $row['site_sid']);
			$sheet->setCellValue('D' . $count, $row['site_name']);
			$sheet->setCellValue('E' . $count, $row['status']);
			//set row style
			if($count % 2 == 0){
				//applying style to even row
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':E'.$count)->applyFromArray($evenRow);
			}
			else{
				//applying style to odd row
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':E'.$count)->applyFromArray($oddRow);
			}
			//increment row
			$count++;
		}
		$writer = new Xlsx($spreadsheet);
		$writer->save($file_name);
		header("Content-Type: application/vnd.ms-excel");
		header('Content-Disposition: attachment; filename="' . basename($file_name) . '"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length:' . filesize($file_name));
		flush();
		readfile($file_name);
		exit;	
	}
}
?>