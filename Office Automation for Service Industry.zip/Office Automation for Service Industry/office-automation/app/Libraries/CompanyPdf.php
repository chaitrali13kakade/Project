<?php
namespace App\Libraries;
use App\Models\CompanyModel;
use Dompdf\Dompdf;
class CompanyPdf
{
	public function createCompanypdf()
	{
		$dompdf = new Dompdf(); 
		$data = [];
		helper(['form']);
		$model = new CompanyModel();
		$result=$model->findAll();
		$data['company']=$result;
		$html  = view('GenerateReport/companyFile',$data);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'orientation');
		$dompdf->render();
		$dompdf->stream('CompanyReport.pdf', array('Attachment' => false));
	}
 
}
?>