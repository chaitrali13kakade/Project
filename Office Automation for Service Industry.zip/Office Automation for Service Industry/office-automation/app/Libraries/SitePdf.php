<?php
namespace App\Libraries;
use App\Models\SiteModel;
use Dompdf\Dompdf;
class SitePdf
{
	public function createSitepdf()
	{
		$dompdf = new Dompdf(); 
		$data = [];
		helper(['form']);
		$model = new SiteModel();
		$result=$model->findAll();
		$data['site']=$result;
		$html  = view('GenerateReport/siteFile',$data); // Get output html
		$dompdf->loadHtml($html); 						// Convert to PDF
		$dompdf->setPaper('A4', 'orientation');
		$dompdf->render();
		$dompdf->stream('SiteReport.pdf', array('Attachment' => false));
	}
 
}
?>