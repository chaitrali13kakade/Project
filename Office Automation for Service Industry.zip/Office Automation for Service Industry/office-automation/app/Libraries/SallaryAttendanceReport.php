<?php
namespace App\Libraries;
use App\Models\TransactionModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class SallaryAttendanceReport
{
	public function attendanceExportToExcel()
	{
        $data = [];
        helper(['form']);
        /* get sallery attendance data into list */
        $model = new TransactionModel();
        $result=$model->getExcelData();
		//$current_date=date('d-m-y H:i:s');
        //set excel file name
		$file_name = 'SallaryAttendanceReport.xlsx';
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
		$spreadsheet->getActiveSheet()->setCellValue('A1',"SALLARY ATTENDANCE REPORT");
		$spreadsheet->getActiveSheet()->mergeCells("A1:K1");
		$spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
		$spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		
		// add style to the header
		$styleArray = [
			'font'=> [
				'color' => ['rgb' => 'FFFFFF'],
				'bold' =>true,
				'size' => 11
			],
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'ff4d4d'],
			],
			'alignment' => [
				'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
			],
			'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],			
		];
		//add style to even row
		$evenRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'd9d9d9'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
            ],

		];
        //add style to odd row
		$oddRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'a6a6a6'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' =>Alignment::HORIZONTAL_CENTER,
            ],

		];
        //applying style to header
		$spreadsheet->getActiveSheet()->getStyle('A2:K2')->applyFromArray($styleArray);
		// auto fit column to content
		foreach(range('A', 'K
			') as $columnID) {
			$spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
       // Set cell  with a string value
		$sheet->setCellValue('A2', 'Sr No');
		$sheet->setCellValue('B2', 'Year');
		$sheet->setCellValue('C2', 'Month');
		$sheet->setCellValue('D2', 'Site Name');
        $sheet->setCellValue('E2', 'ID Code');
		$sheet->setCellValue('F2', 'Employee Name');
		$sheet->setCellValue('G2', 'Designation');
		$sheet->setCellValue('H2', 'Present Days');
        $sheet->setCellValue('I2', 'Weekly Off');
		$sheet->setCellValue('J2', 'Extra Duties');
		$sheet->setCellValue('K2', 'Total');
		
		$sno=1;
		$count = 3;
        //Fill the table data
		foreach($result as $row)
		{
			$sheet->setCellValue('A' . $count, $sno++);
			$sheet->setCellValue('B' . $count, $row['year']);
			$sheet->setCellValue('C' . $count, $row['month']);
			$sheet->setCellValue('D' . $count, $row['site_name']);
			$sheet->setCellValue('E' . $count, $row['employee_id']);
			$sheet->setCellValue('F' . $count, $row['employee_name']);
			$sheet->setCellValue('G' . $count, $row['employee_designnation']);
			$sheet->setCellValue('H' . $count, $row['employee_present_days']);
			$sheet->setCellValue('I' . $count, $row['employee_weeklyoff']);
			$sheet->setCellValue('J' . $count, $row['employee_extraduties']);
			$sheet->setCellValue('K' . $count, $row['total']);
			
			
			
			//set row style
			if($count % 2 == 0){
                //applying style to even row
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':K'.$count)->applyFromArray($evenRow);
			}
			else{
                //applying style to odd row
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':K'.$count)->applyFromArray($oddRow);
			}
			//increment row
			$count++;
		}
		$writer = new Xlsx($spreadsheet);
		$writer->save($file_name);
		//return $this->response->download($file_name, null)->setFileName('sample.xlsx');
		header("Content-Type: application/vnd.ms-excel");
		header('Content-Disposition: attachment; filename="' . $file_name . '"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length:' . filesize($file_name));
		flush();
		readfile($file_name);
		exit;		
		
	}
	
}
?>