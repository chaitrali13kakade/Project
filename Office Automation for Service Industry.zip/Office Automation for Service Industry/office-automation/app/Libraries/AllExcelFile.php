<?php
namespace App\Libraries;
use App\Models\CompanyModel;
use App\Models\SiteModel;
use App\Models\MappingForm_model;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\IOFactory;

class AllExcelFile
{
	
	public function demoexcel()
	{
		$data = [];
		helper(['form']);
		$companymodel = new CompanyModel();
		$resultcompany=$companymodel->findAll();
		$sitemodel = new SiteModel();
		$resultsite=$sitemodel->findAll();
		$mapformmodel = new MappingForm_model();
		$resultmapform=$mapformmodel->findAll();
		// Create new Spreadsheet object
		$spreadsheet = new Spreadsheet();
		// Set document properties
		$spreadsheet->getProperties()->setCreator('PhpOffice')
		->setLastModifiedBy('PhpOffice')
		->setTitle('Office 2007 XLSX Test Document')
		->setSubject('Office 2007 XLSX Test Document')
		->setDescription('PhpOffice')
		->setKeywords('PhpOffice')
		->setCategory('PhpOffice');

		// add style to the header	
		$styleArray = [
			'font'=> [
				'color' => ['rgb' => 'FFFFFF'],
				'bold' =>true,
				'size' => 11
			],
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'ff4d4d'],
			],
			'alignment' => [
				'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
			],
			'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],			
		];
		//even row
		$evenRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'd9d9d9'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];
		//odd row
		$oddRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'a6a6a6'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' =>Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];

		// Add some data
		$spreadsheet->setActiveSheetIndex(0);
		$spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
		$spreadsheet->getActiveSheet()->setCellValue('A1',"Company Report");
		$spreadsheet->getActiveSheet()->mergeCells("A1:D1");
		$spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
		$spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		$spreadsheet->getActiveSheet()->getStyle('A2:D2')->applyFromArray($styleArray);
				// auto fit column to content
		foreach(range('A', 'D
			') as $columnID) {
			$spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$spreadsheet->setActiveSheetIndex(0)->setCellValue('A2', 'Sr No');
		$spreadsheet->setActiveSheetIndex(0)->setCellValue('B2', 'Company Id');
		$spreadsheet->setActiveSheetIndex(0)->setCellValue('C2', 'Company Name');
		$spreadsheet->setActiveSheetIndex(0)->setCellValue('D2', 'Company Status');
		$sno=1;
		$count = 3;
		foreach($resultcompany as $row)
		{
			$spreadsheet->setActiveSheetIndex(0)->setCellValue('A' . $count, $sno++);
			$spreadsheet->setActiveSheetIndex(0)->setCellValue('B' . $count, $row['company_id']);
			$spreadsheet->setActiveSheetIndex(0)->setCellValue('C' . $count, $row['company_name']);
			$spreadsheet->setActiveSheetIndex(0)->setCellValue('D' . $count, $row['status']);
			
			//set row style
			if($count % 2 == 0){
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':D'.$count)->applyFromArray($evenRow);
			}
			else{
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':D'.$count)->applyFromArray($oddRow);
			}
			//increment row
			$count++;
		}
		// Rename worksheet
		$spreadsheet->getActiveSheet()->setTitle('Company Report');
		
		
		$i=1;
		while ($i < 3) 
		{
			if($i == 1)
			{
				//create new sheet
			$spreadsheet->createSheet($i);

			// Add some data
			$spreadsheet->setActiveSheetIndex($i);
			$spreadsheet->getActiveSheet();
			$spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
			$spreadsheet->getActiveSheet()->setCellValue('A1',"Site Report");
			$spreadsheet->getActiveSheet()->mergeCells("A1:E1");
			$spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
			$spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
			$spreadsheet->getActiveSheet()->getStyle('A2:E2')->applyFromArray($styleArray);
				// auto fit column to content
			foreach(range('A', 'E
				') as $columnID) {
				$spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
			}
			$spreadsheet->setActiveSheetIndex($i)->setCellValue('A2', 'Sr No');
			$spreadsheet->setActiveSheetIndex($i)->setCellValue('B2', 'Company Id');
			$spreadsheet->setActiveSheetIndex($i)->setCellValue('C2', 'Site Id');
			$spreadsheet->setActiveSheetIndex($i)->setCellValue('D2', 'Site Id');
			$spreadsheet->setActiveSheetIndex($i)->setCellValue('E2', 'Site Status');
			$ssno=1;
			$scount = 3;
			foreach($resultsite as $row)
			{	
				$spreadsheet->setActiveSheetIndex($i)->setCellValue('A' . $scount, $ssno++);
				$spreadsheet->setActiveSheetIndex($i)->setCellValue('B' . $scount, $row['id']);
				$spreadsheet->setActiveSheetIndex($i)->setCellValue('C' . $scount, $row['site_sid']);
				$spreadsheet->setActiveSheetIndex($i)->setCellValue('D' . $scount, $row['site_name']);
				$spreadsheet->setActiveSheetIndex($i)->setCellValue('E' . $scount, $row['status']);
					//set row style
				if($scount % 2 == 0){
					$spreadsheet->getActiveSheet()->getStyle('A'.$scount.':D'.$scount)->applyFromArray($evenRow);
				}
				else{
					$spreadsheet->getActiveSheet()->getStyle('A'.$scount.':D'.$scount)->applyFromArray($oddRow);
				}
					//increment row
				$scount++;	
			}

			// Rename worksheet
			$spreadsheet->getActiveSheet()->setTitle('Site Report');

				break;
			}
			
			$i++;

		}

		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$spreadsheet->setActiveSheetIndex(0);
		// Redirect output to a client’s web browser (Xlsx)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="AllFilesReport.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		// If you're serving to IE over SSL, then the following may be needed
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
		header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header('Pragma: public'); // HTTP/1.0
		$writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
		$writer->save('php://output');
		exit;
	}

}