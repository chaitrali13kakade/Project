<?php
namespace App\Libraries;
use App\Models\CompanyModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class CompanyExcel
{
	public function createCompanyExcel()
	{
		$data = [];
		helper(['form']);
		$model = new CompanyModel();
		$result=$model->findAll();
		$file_name = 'CompanyReport.xlsx';
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
		$spreadsheet->getActiveSheet()->setCellValue('A1',"Company Report");
		$spreadsheet->getActiveSheet()->mergeCells("A1:D1");
		$spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
		$spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		

		// add style to the header
		$styleArray = [
			'font'=> [
				'color' => ['rgb' => 'FFFFFF'],
				'bold' =>true,
				'size' => 11
			],
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'ff4d4d'],
			],
			'alignment' => [
				'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
			],
			'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],			
		];
		//even row
		$evenRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'd9d9d9'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];
		//odd row
		$oddRow = [
			'fill' => [
				'fillType' => Fill::FILL_SOLID,
				'startColor' =>['rgb' => 'a6a6a6'],
			],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => '666666'],
                ],
            ],
            'alignment' => [
                'horizontal' =>Alignment::HORIZONTAL_CENTER,
				'vertical'   => Alignment::HORIZONTAL_CENTER,
            ],
		];
		$spreadsheet->getActiveSheet()->getStyle('A2:D2')->applyFromArray($styleArray);
				// auto fit column to content
		foreach(range('A', 'D
			') as $columnID) {
			$spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$sheet->setCellValue('A2', 'Sr No');
		$sheet->setCellValue('B2', 'Company Id');
		$sheet->setCellValue('C2', 'Company Name');
		$sheet->setCellValue('D2', 'Company Status');
		
		$sno=1;
		$count = 3;
		foreach($result as $row)
		{
			$sheet->setCellValue('A' . $count, $sno++);
			$sheet->setCellValue('B' . $count, $row['company_id']);
			$sheet->setCellValue('C' . $count, $row['company_name']);
			$sheet->setCellValue('D' . $count, $row['status']);
			
			//set row style
			if($count % 2 == 0){
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':D'.$count)->applyFromArray($evenRow);
			}
			else{
				$spreadsheet->getActiveSheet()->getStyle('A'.$count.':D'.$count)->applyFromArray($oddRow);
			}
			//increment row
			$count++;
		}
		$writer = new Xlsx($spreadsheet);
		$writer->save($file_name);
		//return $this->response->download($file_name, null)->setFileName('sample.xlsx');
		header("Content-Type: application/vnd.ms-excel");
		header('Content-Disposition: attachment; filename="' . $file_name . '"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length:' . filesize($file_name));
		flush();
		readfile($file_name);
		exit;		
		
	}
	
}
?>