<?php
namespace App\Libraries;
use App\Models\MappingForm_model;
use Dompdf\Dompdf;
class MapFormPdf
{
	public function createMapformpdf()
	{
		$dompdf = new Dompdf(); 
		$data = [];
		helper(['form']);
		$model = new MappingForm_model();
		$result=$model->findAll();
		$data['mapForm']=$result;
		$html  = view('GenerateReport/mapForm_File',$data);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'orientation');
		$dompdf->render();
		$dompdf->stream('MapFormReport.pdf', array('Attachment' => false));
	}
 
}
?>